/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.iniciar;

/**
 *
 * @author 026718
 */
public class Iniciar {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
