package com.mycompany.sistema_escolar1;

public class Sistema_escolar1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
