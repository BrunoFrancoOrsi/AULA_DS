/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistema_escolar1;

/**
 *
 * @author 026718
 */
public class Sistema_escolar1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
