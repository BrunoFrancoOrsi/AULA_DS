/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.etec_escola1;

/**
 *
 * @author 026718
 */
public class Etec_Escola1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
