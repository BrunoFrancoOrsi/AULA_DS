package com.mycompany.etec_escola1;

public class Etec_Escola1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
