package com.mycompany.sistemacrud;

public class SistemaCrud {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
