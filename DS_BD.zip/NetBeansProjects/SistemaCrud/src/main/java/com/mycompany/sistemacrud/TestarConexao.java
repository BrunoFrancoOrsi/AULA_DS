package com.mycompany.sistemacrud;

import java.sql.Connection;
import java.sql.DriverManager;        
import java.sql.SQLException;        
        
public class TestarConexao {
    private static final String URL = "jdbc:mysql://localhost:3306" + "/escola?useSSL=false&serverTimezone=UTC";
    private static final String USUARIO = "root";
    private static final String SENHA = "etec110";
}
