package com.mycompany.calculadora_imc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class imc_controller {
    
    private imc_model model;
    private imc_view view;

    public imc_controller(imc_model model, imc_view view) {
        this.model = model;
        this.view = view;
        
        this.view.addCalcularListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            calcularIMC();
        }
    }); 
    }
    
    private void calcularIMC(){
        try{
            double peso = Double.parseDouble(view.getPesoTexto().replace(",", "."));
            double altura = Double.parseDouble(view.getAlturaTexto().replace(",", "."));
            
            model.setPeso(peso);
            model.setAltura(altura);
            
            double imc = model.calcularIMC();
            String classificacao = model.obterClassificacao(imc);
            
            String resultado = String.format("IMC: %.2f (%s)", imc,  classificacao);
            view.setResultado(resultado);
            
        } catch (NumberFormatException ex) {
            view.exibirMensagem("Por favor, insira valores numericos.");
        } catch (IllegalArgumentException ex) {
            view.exibirMensagem(ex.getMessage());
        }
    }
    
}
