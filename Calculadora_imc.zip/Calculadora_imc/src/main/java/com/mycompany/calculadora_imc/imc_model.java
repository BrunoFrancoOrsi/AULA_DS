package com.mycompany.calculadora_imc;

public class imc_model {
    
    private double peso;
    private double altura;

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public double calcularIMC() {
        if(altura <= 0){
            throw new IllegalArgumentException("A altura deve ser maor que zero");
        } 
        return peso / (altura * altura);
    }
    
    public String obterClassificacao(double imc){
        if(imc < 18.5) return "Abaixo do peso";
        if(imc < 24.9) return "Peso normal";
        if(imc < 29.9) return "Sobrepeso";
        if(imc < 34.9) return "Obesidade grau I";
        if(imc < 39.9) return "Obesidade grau II";
        return "Obesidade grau III";
    }
}
