package com.mycompany.calculadora_imc;

public class Calculadora_imc {

    public static void main(String[] args) {
        imc_model model = new imc_model();
        imc_view view = new imc_view();
        imc_controller controller = new imc_controller(model, view);
        
        view.setVisible(true);
    }
}
