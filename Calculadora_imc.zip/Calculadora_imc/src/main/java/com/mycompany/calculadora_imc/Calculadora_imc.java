/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora_imc;

/**
 *
 * @author 026718
 */
public class Calculadora_imc {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
