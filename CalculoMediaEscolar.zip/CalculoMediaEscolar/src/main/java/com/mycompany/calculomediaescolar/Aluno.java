package com.mycompany.calculomediaescolar;

public class Aluno {

    private String nome;
    private double nota1;
    private double nota2;
    private double nota3;
    private double nota4;
    private double frequencia;

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setNota1(double nota1) {
        this.nota1 = nota1;
    }

    public void setNota2(double nota2) {
        this.nota2 = nota2;
    }

    public void setNota3(double nota3) {
        this.nota3 = nota3;
    }

    public void setNota4(double nota4) {
        this.nota4 = nota4;
    }

    public void setFrequencia(double frequencia) {
        this.frequencia = frequencia;
    }
    
    public double calcularMedia() {
        if(nota1 <= 0 || nota2 <= 0 || nota3 <= 0 || nota4 <= 0){
            throw new IllegalArgumentException("A nota deve ser maior que zero");
        } 
        return (nota1 + nota2 + nota3 + nota4) / 4;
    }
    
    public String obterAprovacao(double media){
        if(media <= 5 && frequencia >= 75 || media <= 5 && frequencia < 75) return "Reprovado";
        else if(media <= 10 &&  media > 5 && frequencia <= 100 && frequencia >= 75) return "Aprovado";
        else return "Reprovado";
    }
}
