package com.mycompany.calculomediaescolar;

public class CalculoMediaEscolar {

    public static void main(String[] args) {
        Aluno model = new Aluno();
        BoletimView view = new BoletimView();
        BoletimController controller = new BoletimController(model, view);
        
        view.setVisible(true);
    }
}
