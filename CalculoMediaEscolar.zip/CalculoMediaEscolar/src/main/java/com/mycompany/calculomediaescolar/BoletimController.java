package com.mycompany.calculomediaescolar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BoletimController {
    
    private Aluno model;
    private BoletimView view;
    
    public BoletimController(Aluno model, BoletimView view) {
        this.model = model;
        this.view = view;
        
        this.view.addCalcularListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            calcularMedia();
        }
    }); 
    }
    
    private void calcularMedia(){
        try{
            double nota1 = Double.parseDouble(view.getNota1Texto().replace(",", "."));
            double nota2 = Double.parseDouble(view.getNota2Texto().replace(",", "."));
            double nota3 = Double.parseDouble(view.getNota3Texto().replace(",", "."));
            double nota4 = Double.parseDouble(view.getNota4Texto().replace(",", "."));
            double frequencia = Double.parseDouble(view.getFrequenciaTexto().replace(",", "."));
            
            model.setNota1(nota1);
            model.setNota2(nota2);
            model.setNota3(nota3);
            model.setNota4(nota4);
            model.setFrequencia(frequencia);
            
            double media = model.calcularMedia();
            String aprovacao = model.obterAprovacao(media);
            
            String resultado = String.format("Media: %.2f (%s)", media,  aprovacao);
            view.setResultado(resultado);
            
        } catch (NumberFormatException ex) {
            view.exibirMensagem("Por favor, insira valores numericos.");
        } catch (IllegalArgumentException ex) {
            view.exibirMensagem(ex.getMessage());
        }
    }
    
}
